# Forex Trading Engine — Changelog

All notable changes. Format: Semantic Versioning (MAJOR.MINOR.PATCH).

## [1.0.0] — 2026-09-21  — Phase-1: MT5 + Python, auto-mode
### Added
- SMC OBJECT LAYER (`smc_objects.py`), causal / no-repaint / no-look-ahead:
  swings + HH/HL/LH/LL labels, BOS/CHoCH, displacement, order blocks
  (+mitigation +breaker), pullback+reaction (entry), FVG/IFVG, liquidity void,
  volume imbalance*, BPR, internal (multi-tier) structure, inducement (IDM),
  SCOB, Quasimodo (faithful spec), Unicorn, liquidity pools (BSL/SSL, EQH/EQL),
  sweeps/raids, OTE, premium/discount, PDH/PDL/PWH/PWL, sessions + Power-of-3
  (AMD), Judas, NDOG, fib grid + extension targets, HTF bias.
- `broker_profile.py` — auto (live MT5) / manual / hybrid capture; server→UTC,
  symbol map, spread cost.
- `news_feed.py` — economic calendar, high-impact filter, news-blackout flag,
  top-left dashboard block.
- `mt5_adapter.py` — MT5 CSV export + live copy_rates → UTC OHLC.
- `auto_engine.py` — autonomous orchestrator (detect→gate→size→place→manage→log),
  MockBroker (test) + MT5Broker (live). Safety: demo-default, hard-stop-always,
  daily-loss halt, max-positions, max-total-risk, spread guard, news blackout.
- `data_library/` — 9 instruments (5m/15m/1h/4h) + 21y hourly gold + loader/refetch.
- `version.py` — single-source brand + version.

### Verified (in research env)
- Object layer audited: 9 core detectors 100% correct; QM fixed to faithful spec.
- Broker manual/hybrid, news logic, MT5 CSV adapter, full autonomous loop on real data.
- SMC edge measured on 21y gold: CHoCH+Silver-Bullet ~2%/yr, decade out-of-sample stable.

### Known limits / your-side validation
- *Volume Imbalance inapplicable to continuous OHLC (needs tick/gappy data).
- SMT divergence: buildable now (multi-instrument data loaded) but NOT yet built.
- Volumetric OB: needs real volume (tick-count unreliable) — deferred.
- Live paths (auto broker capture, copy_rates, MT5Broker orders): validate on your MT5.
- Data sources are public/unverified; metal prices in 2026 window run high — verify.

## [Unreleased] — planned
- 1.1.0: SMT divergence object; strategy-assembly framework (named SMC setups
  into the orchestrator signal hook); cross-market edge test across 9 instruments.
- 1.2.0 / Phase-2: MQL5 native EA + object-layer port + parity harness;
  TradingView Pine port + webhook bridge.
