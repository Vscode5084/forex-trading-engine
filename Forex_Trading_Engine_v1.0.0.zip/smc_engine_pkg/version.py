"""
Forex Trading Engine — central version + brand stamp.
Import this everywhere so the version is single-sourced.
"""
ENGINE_NAME    = "Forex Trading Engine"
ENGINE_VERSION = "1.0.0"          # MAJOR.MINOR.PATCH
ENGINE_STAGE   = "Phase-1 (MT5 + Python, auto-mode)"
ENGINE_BUILD   = "2026-09-21"
ENGINE_AUTHOR  = "Amex Solutions"

def banner():
    return f"{ENGINE_NAME} v{ENGINE_VERSION} — {ENGINE_STAGE} — build {ENGINE_BUILD}"

if __name__ == "__main__":
    print(banner())
